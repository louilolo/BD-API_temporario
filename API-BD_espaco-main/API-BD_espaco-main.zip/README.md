# App-BD_espaco
Repositório contendo API para conectar e ditar regras entre app e BD para gestão de espaço
